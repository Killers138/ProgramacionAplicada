#Programa_Leds

from machine import Pin
import time

#Definicion_pin

leds = [Pin(i, Pin.OUT)for i in (23, 22, 21, 19, 17, 0, 2, 15)]

while True:
  for led in leds:
    led.value(1)
    time.sleep(0.2)
    led.value(0)

  for led in reversed (leds):
    led.value(1)
    time.sleep(0.2)
    led.value(0)
